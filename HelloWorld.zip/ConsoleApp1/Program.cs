﻿// Hello World! Program
// By Jason Plimpton
// For Class CIS-162AD
// 09/06/2020

namespace Program
{
    class Print
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!\r\n");
            System.Console.WriteLine("This is Jason Plimpton's first C# app!\r\n");
            System.Console.WriteLine("Press enter to close...");
            System.Console.ReadLine();
        }
    }
}